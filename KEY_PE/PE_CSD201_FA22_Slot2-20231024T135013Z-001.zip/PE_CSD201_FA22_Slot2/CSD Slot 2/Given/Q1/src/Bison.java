// =========== DO NOT EDIT THE GIVEN CONTENT OF THIS FILE ============
class Bison {
  String forest;
  int hoof,hair;
  Bison() {
   }
  Bison(String xForest, int xHoof, int xHair){
    forest=xForest;hoof=xHoof; hair=xHair;
   }
  public String toString(){
    return("(" +forest+","+hoof + "," + hair + ")");
   }
 }
